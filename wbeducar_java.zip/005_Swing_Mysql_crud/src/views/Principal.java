package views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Principal {

	public JFrame frmVentanaPrincipal;
	private JTextField txtAccesoOk;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal window = new Principal();
					window.frmVentanaPrincipal.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Principal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmVentanaPrincipal = new JFrame();
		frmVentanaPrincipal.getContentPane().setBackground(new Color(255, 0, 102));
		frmVentanaPrincipal.setBounds(100, 100, 450, 300);
		frmVentanaPrincipal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmVentanaPrincipal.getContentPane().setLayout(null);
		
		txtAccesoOk = new JTextField();
		txtAccesoOk.setFont(new Font("Trajan Pro 3", Font.BOLD, 36));
		txtAccesoOk.setBackground(new Color(255, 0, 102));
		txtAccesoOk.setText("Acceso ok");
		txtAccesoOk.setBounds(10, 32, 252, 60);
		frmVentanaPrincipal.getContentPane().add(txtAccesoOk);
		txtAccesoOk.setColumns(10);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"id", "usuario", "contrase\u00F1a", "esatdo"},
			},
			new String[] {
				"New column", "New column", "New column", "New column"
			}
		));
		table.setBounds(184, 119, 217, 106);
		frmVentanaPrincipal.getContentPane().add(table);
	}
}
