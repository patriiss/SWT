package views;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import config.Conexion;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class Login {

	private JFrame frmAccesoADatos;
	private JTextField txtUsuario;
	private JTextField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frmAccesoADatos.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAccesoADatos = new JFrame();
		frmAccesoADatos.getContentPane().setBackground(new Color(51, 204, 204));
		frmAccesoADatos.getContentPane().setLayout(null);

		JLabel lblNombre = new JLabel("nombre");
		lblNombre.setFont(new Font("Trajan Pro 3", Font.BOLD, 16));
		lblNombre.setBounds(49, 59, 106, 14);
		frmAccesoADatos.getContentPane().add(lblNombre);

		JLabel lblContrasea = new JLabel("contrase\u00F1a");
		lblContrasea.setFont(new Font("Trajan Pro 3", Font.BOLD, 16));
		lblContrasea.setBounds(49, 113, 161, 14);
		frmAccesoADatos.getContentPane().add(lblContrasea);

		txtUsuario = new JTextField();
		txtUsuario.setBounds(200, 58, 131, 20);
		frmAccesoADatos.getContentPane().add(txtUsuario);
		txtUsuario.setColumns(10);

		txtPassword = new JTextField();
		txtPassword.setBounds(200, 112, 131, 20);
		frmAccesoADatos.getContentPane().add(txtPassword);
		txtPassword.setColumns(10);

		JButton btnLogin = new JButton("Acceder");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				acceder();

			}
		});
		btnLogin.setForeground(new Color(0, 0, 0));
		btnLogin.setBackground(new Color(0, 102, 204));
		btnLogin.setBounds(151, 174, 117, 38);
		frmAccesoADatos.getContentPane().add(btnLogin);
		frmAccesoADatos.setBounds(100, 100, 450, 300);
		frmAccesoADatos.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	private void acceder() {

		Connection conn = new Conexion().conectar(); // importar el de java.sql

		try {
			PreparedStatement ps = conn.prepareStatement("SELECT  * FROM user WHERE username = ? AND password = ?");
			ps.setString(1, txtUsuario.getText());
			ps.setString(2, txtPassword.getText());

			ResultSet rs = ps.executeQuery();// ejecutar la select

			//System.out.println(rs.next());
			
			if (rs.next()) {
				
				Principal p = new Principal();
				p.frmVentanaPrincipal.setVisible(true);
				
			}else {
				JOptionPane.showMessageDialog(null, "error de login");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}// cierre acceder
}// cierre clase
