package application;
	
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.fxml.FXMLLoader;


public class Main extends Application {
	
	private ObservableList<Productos> productData = FXCollections.observableArrayList();

    /**
     * Constructor
     */
    public Main() {
        // Add some sample data
    	productData.add(new Productos("Sudadero", 18, 25));
    	productData.add(new Productos("Cabezada de cuadra", 25, 15));
        productData.add(new Productos("riendas", 10,20));
        productData.add(new Productos("cincha", 8, 10));
        productData.add(new Productos("montura", 12, 200));
        productData.add(new Productos("vendas", 28, 16));
        productData.add(new Productos("protectores", 20, 15));
        productData.add(new Productos("bajo venda", 16, 10));
        productData.add(new Productos("ramal", 26, 8));
    }
  
    /**
     * Returns the data as an observable list of Persons. 
     * @return
     */
    public ObservableList<Productos> getProductData() {
        return productData;
    }
	@Override
	public void start(Stage primaryStage) {
		try {
			FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Sample.fxml"));
			HBox root = (HBox)loader.load();
			Scene scene = new Scene(root,500,500);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			
			SampleController controller = loader.getController();
			controller.setMainApp(this);
			
			
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
